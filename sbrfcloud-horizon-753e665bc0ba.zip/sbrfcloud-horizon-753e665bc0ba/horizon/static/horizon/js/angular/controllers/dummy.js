(function () {
  'use strict';
  angular.module('hz')
    .controller('DummyCtrl', function () {});
}());
